"use client";

import { createContext, useContext, useState, useCallback, useMemo, useEffect } from "react";
import { useAccount, useDisconnect, useConnect } from "wagmi";
import { injected } from "wagmi/connectors";

type SessionState = {
  ready: boolean;
  isConnected: boolean;
  address: `0x${string}` | undefined;
  chainId: number | undefined;
  connect: () => Promise<void>;
  disconnect: () => Promise<void>;
  // NEW: Track if user explicitly connected
  setUserConnected: (val: boolean) => void;
};

const SessionContext = createContext<SessionState | null>(null);

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const { connect } = useConnect();
  const { disconnect } = useDisconnect();
  const { address, isConnected, chainId } = useAccount();

  const [ready, setReady] = useState(false);
  const [userConnected, setUserConnected] = useState(false);

  // Mark as ready once Wagmi is initialized
  useEffect(() => {
    setReady(true);
  }, []);

  // FIX: If the user hasn't clicked connect, force disconnect on mount
  useEffect(() => {
    if (ready && !userConnected && isConnected) {
      disconnect();
    }
  }, [ready, userConnected, isConnected, disconnect]);

  const connectWallet = useCallback(async () => {
    // Mark that the user initiated the connection
    setUserConnected(true);
    try {
      await connect({ connector: injected() });
    } catch (err) {
      console.error("Connection failed:", err);
    }
  }, [connect]);

  const disconnectWallet = useCallback(async () => {
    setUserConnected(false);
    try {
      await disconnect();
    } catch (err) {
      console.error("Disconnection failed:", err);
    }
  }, [disconnect]);

  const value = useMemo(
    () => ({
      ready,
      isConnected,
      address,
      chainId,
      connect: connectWallet,
      disconnect: disconnectWallet,
      setUserConnected,
    }),
    [ready, isConnected, address, chainId, connectWallet, disconnectWallet]
  );

  return (
    <SessionContext.Provider value={value}>
      {children}
    </SessionContext.Provider>
  );
}

export function useSession() {
  const context = useContext(SessionContext);
  if (!context) {
    throw new Error("useSession must be used within a SessionProvider");
  }
  return context;
}