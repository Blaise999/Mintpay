"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { LandingPage } from "@/components/landing/landing-page";
import { useSession } from "@/components/session-provider";

export default function HomePage() {
  const router = useRouter();
  const session = useSession();
  
  const isReady = session.ready;
  const isConnected = session.isConnected;

  // Redirect if connected
  useEffect(() => {
    if (isReady && isConnected) {
      const timeout = setTimeout(() => {
        router.replace("/dashboard");
      }, 200);
      return () => clearTimeout(timeout);
    }
  }, [isReady, isConnected, router]);

  // --- RENDER LOGIC ---

  // 1. Not Ready: Show Landing Page
  if (!isReady) {
    return <LandingPage />;
  }

  // 2. Connected: Show Loading (briefly before redirect)
  if (isConnected) {
    return (
      <div className="fixed inset-0 z-[9999] bg-slate-950 flex items-center justify-center">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-white"></div>
      </div>
    );
  }

  // 3. Not Connected: Show Landing Page
  return <LandingPage />;
}